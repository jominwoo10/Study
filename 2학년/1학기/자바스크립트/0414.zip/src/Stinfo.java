
public class Stinfo {
	String name;
	String phone;
	int age;
}
