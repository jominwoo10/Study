
public class RunCircle {

	public static void main(String[] args) {
		Circle c = new Circle(5);
		c.calcAndPrint();
	}

}
