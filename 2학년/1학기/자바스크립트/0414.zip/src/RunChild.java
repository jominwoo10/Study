
public class RunChild {

	public static void main(String[] args) {
		Child c = new Child();
		
		c.play();
		c.eat();
		c.walk();
		
	}

}
