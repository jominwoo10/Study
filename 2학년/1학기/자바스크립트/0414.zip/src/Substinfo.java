
public class Substinfo extends Stinfo {
	String addr;
}
