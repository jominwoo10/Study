package yuhan.spring.auto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Student {
	
	@Autowired
	@Qualifier("yuhan01")
	private Ballpen ballpen;

	public Ballpen getBallpen() {
		return ballpen;
	}

	public void setBallpen(Ballpen ballpen) {
		this.ballpen = ballpen;
	}
	
	public void useStudent() {
		System.out.println("�� ������ ���� ����ϴ� �����Դϴ�.");
		this.ballpen.display();
	}

}
