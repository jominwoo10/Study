package yuhan.spring.auto;

public class Test {
	int a;
	String b;
	Double c;
	public static void main(String[] args) {
		
		
		
	}
}
