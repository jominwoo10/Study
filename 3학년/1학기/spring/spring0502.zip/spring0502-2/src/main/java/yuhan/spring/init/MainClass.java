package yuhan.spring.init;

import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext();
		ctx.load("classpath:baseball.xml");
		ctx.refresh();
		
		Player player1 = ctx.getBean("player1",Player.class);
		System.out.println("�����̸� : " +player1.getName());
		System.out.println("���� : " +player1.getAge());
		System.out.println("������ : " +player1.getPosition());
		System.out.println("���� : " +player1.getHeight());
		System.out.println("ü�� : " +player1.getWeight());
		
		System.out.println("==================================");
		
		Player player2 = ctx.getBean("player2",Player.class);
		System.out.println("�����̸� : " +player2.getName());
		System.out.println("���� : " +player2.getAge());
		System.out.println("������ : " +player2.getPosition());
		System.out.println("���� : " +player2.getHeight());
		System.out.println("ü�� : " +player2.getWeight());
	}

}
