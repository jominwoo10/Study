package yuhan.spring.model;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserController {
	@RequestMapping(value="/userForm", method=RequestMethod.GET)
	public String userForm() {
		return "user/userForm1";
	}
	@ModelAttribute("customerId")
	public String[] customerId() {
		return new String[] {"����","���ǵ��","����"};
	}
	
	@ModelAttribute("userVo")
	public UserVo inti(HttpServletRequest request) {
		if(request.getMethod().equalsIgnoreCase("GET")) {
			
		UserVo userVo = new UserVo();
		
		userVo.setId("���̵� �Է��ϼ���...");
		userVo.setPw("�н����带 �Է��ϼ���...");
		userVo.setName("�̸��� �Է��ϼ���...");
		userVo.setAddress("�ּҸ� �Է��ϼ���...");
		userVo.setHobby("��̸� �Է��ϼ���...");
		return null;
		}
		else
			return new UserVo();
	}
	@RequestMapping(value="/userSave",method=RequestMethod.POST)
	public ModelAndView UserSave(@ModelAttribute("userVo")UserVo userVo, Model model) {
		model.addAttribute("msg","ȸ������ ����Դϴ�");
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("user/userInfo1");
		modelAndView.addObject("userVo",userVo);
		return modelAndView;
	}
}

