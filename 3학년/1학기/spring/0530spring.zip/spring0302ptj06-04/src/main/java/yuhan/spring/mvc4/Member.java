package yuhan.spring.mvc4;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class Member {
	@RequestMapping("/login")
	public String goLogin() {
		return "login";
	}
	@RequestMapping("/student")
	public String JoinData(Student student, Model model) {
		String name = student.getName();
		String id = student.getId();
		String pw = student.getPw();
		String email = student.getEmail();
		
		model.addAttribute("studentName",name);
		model.addAttribute("studentId",id);
		model.addAttribute("studentPw",pw);
		model.addAttribute("studentEmail",email);
		
		return "student/studentId";
	}
}
