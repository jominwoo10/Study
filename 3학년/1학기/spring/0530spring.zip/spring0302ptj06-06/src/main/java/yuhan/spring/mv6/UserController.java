package yuhan.spring.mv6;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class UserController {
	
	@ModelAttribute("costomerId")
	public String[] refcostomerId() {
		
		return new String[] {"����","����","���尡�ٱ�","����"};
	}
	@RequestMapping(value="userForm.sp", method=RequestMethod.GET)
	public String userForm() {
		System.out.println("----userController. userForm()----");
		return "user/userForm2";
	}
}
