package yuhan.spring.mvc2;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class YuhanClass {
	@RequestMapping("/login")
	public String goLogin() {
		return "login";
	}
	
	@RequestMapping(value="/student",method=RequestMethod.GET)
	public String goStudent(HttpServletRequest httpServletRequest, Model model) {
		String id = httpServletRequest.getParameter("id");
		String pw = httpServletRequest.getParameter("pw");
		
		model.addAttribute("studentId",id);
		model.addAttribute("studentPw",pw);
		
		return "student/studentId";
	}
}
