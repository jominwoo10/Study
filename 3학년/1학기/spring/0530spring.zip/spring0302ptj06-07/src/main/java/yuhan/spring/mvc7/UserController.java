package yuhan.spring.mvc7;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserController {
	
	@ModelAttribute("costomerId")
	public String[] refcostomerId() {
		
		return new String[] {"����","����","���尡�ٱ�","����"};
	}
	@RequestMapping(value="userForm.sp", method=RequestMethod.GET)
	public String userForm() {
		System.out.println("----userController. userForm()----");
		return "user/userForm2";
	}
	
	@RequestMapping(value="/userSave", method=RequestMethod.POST)
	public ModelAndView userSvae(@ModelAttribute("userVo") UserVo userVo, Model model) {
		model.addAttribute("msg", "ȸ������ ��� ����");
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("user/userInfo2");
		modelAndView.addObject("userVo",userVo);
		
		return modelAndView;
	}
}
