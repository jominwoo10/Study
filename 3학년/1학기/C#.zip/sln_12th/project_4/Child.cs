﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_4
{
    class Child : Parent
    {
        public Child()
        {
            Console.WriteLine("자식 생성자");
        }
    }
}
