﻿using System;
using System.Collections.Generic;

namespace project_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Dog 클래스와 Cat 클래스의 인스턴스를 만들고 메소드 실행

            List<Dog> Dogs = new List<Dog>() { new Dog(), new Dog(), new Dog() };
            List<Cat> Cats = new List<Cat>() { new Cat(), new Cat(), new Cat() };

            foreach (var item in Dogs)
            {
                item.Eat();
                item.Sleep();
                item.Bark();
            }
            Console.WriteLine();
            foreach (var item in Cats)
            {
                item.Eat();
                item.Sleep();
                item.Bark();
            }
        }
    }
}
