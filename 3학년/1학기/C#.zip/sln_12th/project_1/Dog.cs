﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_1
{
    class Dog
    {
        public int Age { get; set; } //속성
        public string color { get; set; }
        public Dog() { this.Age = 0; } //생성자

        public void Eat() { Console.WriteLine("욤욤"); }
        public void Sleep() { Console.WriteLine("쿨쿨"); }
        public void Bark() { Console.WriteLine("왈왈"); }
    }
}
