﻿using System;
using System.Collections.Generic;

namespace project_3
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Animal> Animals = new List<Animal>()
            {
                new Dog(), new Cat(), new Dog(), new Cat(),
                new Dog(), new Cat(), new Dog(), new Cat()
            };

            foreach (var item in Animals)
            {
                item.Eat();
                item.Sleep();

                //일반적인 자료형 변환
                /*if(item is Dog) { ((Dog)item).Bark(); }
                if(item is Cat) { ((Cat)item).Meow(); }

                if (item is Dog) { (item as Dog).Bark(); }
                if (item is Cat) { (item as Cat).Meow(); }*/

                //as 키워드를 사용하는 경우의 일반적인 형태
                var dog = item as Dog;
                if (dog != null) { dog.Bark(); }
                var cat = item as Cat;
                if (cat != null) { cat.Meow(); }
            }
        }
    }
}
