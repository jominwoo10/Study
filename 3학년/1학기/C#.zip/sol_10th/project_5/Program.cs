﻿using System;

namespace project_5
{
    class Product
    {
        public static int counter = 0; //클래스 변수
        public int id; //인스턴스 변수
        public string name;
        public int price;
        
        public Product(string name, int price)
        {
            Product.counter = counter + 1;
            this.id = counter;
            this.name = name;
            this.price = price;
        }
        
        ~Product() // 소멸자(한 클래스에 하나만)
        {
            Console.WriteLine(name + "의 소멸자 호출");
            Console.WriteLine("굿바이~");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Product productA = new Product("감자", 2000);
            Product productB = new Product("고구마", 3000);

            Console.WriteLine(productA.id + "번 상품의 이름" + productA.name);
            Console.WriteLine(productB.id + "번 상품의 이름" + productB.name);
            Console.WriteLine("전체 상픔의 개수 : " + Product.counter);
        }
    }
}
