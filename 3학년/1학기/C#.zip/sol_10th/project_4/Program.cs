﻿using System;

namespace project_4
{
    class Cat
    {
        public string Name;
        public string Color;
        public int Age;

        public void Meow()
        {
            Console.WriteLine($"{Name} : 야옹~");
        }

        public Cat(string name, string color, int age)
        {
            Name = name;
            Color = color;
            Age = age;

        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Cat kitty = new Cat("키티","하얀색",18 );
            kitty.Meow();
            Console.WriteLine($"{kitty.Name} : {kitty.Color}, {kitty.Age}");
            
        }
    }
}
