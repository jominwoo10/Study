﻿using System;

namespace project_2
{
    class Test
    {
        public int Power(int x) // 인스턴스 메서드
        {
            return x * x;
        }
    }

    class MyMath
    {
        public static int Abs (int input) //클래스 메서드
        {
            if(input < 0)
            {
                return -input;
            }
            else
            {
                return input;
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Test test = new Test();
            Console.WriteLine(test.Power(10));
            Console.WriteLine(test.Power(20));

            //MyMath myMath = new MyMath();
            //Console.WriteLine(myMath.Abs(-52));
            Console.WriteLine(MyMath.Abs(-52));
            Console.WriteLine(MyMath.Abs(52));
        }
    }
}
