﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _10th
{
    class Car
    {
        public static void Hi() // sattic x = 인스턴스 메소드 , static o = 클래스 메소드
        {
            Console.WriteLine("안녕하세요~");

        }
        public static void Go()
        {
            Console.WriteLine("전진하시오");
        }
    }
}
