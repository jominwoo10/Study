﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _10th
{
    class Product
    {
        public string name;
        public int price;

    }
}
