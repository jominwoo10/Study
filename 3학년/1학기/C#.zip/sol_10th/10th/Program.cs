﻿using System;

namespace _10th
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Book book = new Book();
            
            book.title = "된장찌개";
            book.contents = "된장찌개 맛있어";
            book.writer = "유산슬";
            book.publisher = "도서출판 분식집";
            book.published_Date =20220504;

            Console.WriteLine("제목 : " + book.title);
            Console.WriteLine("제목 : {0}" , book.title);
            Console.WriteLine($"제목 : { book.title}");
            Console.WriteLine("내용 : " + book.contents);
            Console.WriteLine("저자 : " + book.writer);
            Console.WriteLine("출판사 : " + book.publisher);
            Console.WriteLine("출판일 : " + book.published_Date);
            Console.WriteLine();

            Product product = new Product();
            product.name = "감자";
            product.price = 2000;
            Console.WriteLine(product.name + " : " + product.price + "원");
            Console.WriteLine();

            Product productA = new Product() { name = "감자", price = 5000 };
            Product productB = new Product() { name = "고구마", price = 6000 };
            Product productC = new Product() { name = "토란", price = 4000 };
            Product productD = new Product() { name = "토마토", price = 3000 };

            Console.WriteLine(productA.name + " : " + productA.price + "원");
            Console.WriteLine(productB.name + " : " + productB.price + "원");
            Console.WriteLine(productC.name + " : " + productC.price + "원");
            Console.WriteLine(productD.name + " : " + productD.price + "원");*/

            /*Car car = new Car();  //인스턴스 메소드 
            car.Hi();
            car.Go();*/
            Car.Hi();  // 클래스 메소드
            Car.Go();

            Console.WriteLine("MyMath.Pi : " + MyMath.PI);

        }
    }
}

