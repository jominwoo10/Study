﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _10th
{
    class Book
    {
        public string title;
        public string contents;
        public string writer;
        public string publisher;
        public int published_Date;

    }
}
