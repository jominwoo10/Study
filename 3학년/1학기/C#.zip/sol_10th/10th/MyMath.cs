﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _10th
{
    class MyMath
    {
        public static double PI = 3.141592;

    }
}
