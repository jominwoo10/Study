﻿using System;

namespace project_3
{
    class MyMath
    {
        public static int Plus(int a, int b)
        {
            Console.WriteLine("calling int Plus(int ,int)");
            return a+b;
        }
        public static int Plus(int a, int b, int c)
        {
            Console.WriteLine("calling int Plus(int ,int,int)");
            return a + b + c;
        }
        public static double Plus(double a, double b)
        {
            Console.WriteLine("calling int Plus(double ,double)");
            return a + b;
        }
        public static double Plus(int a, double b)
        {
            Console.WriteLine("calling int Plus(int ,double)");
            return a + b;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(MyMath.Plus(1,2));
            Console.WriteLine(MyMath.Plus(1, 2,3));
            Console.WriteLine(MyMath.Plus(10.0, 2.4));
            Console.WriteLine(MyMath.Plus(11, 2.4));
        }
    }
}
