﻿using System;
using System.Collections.Generic;

namespace project_3
{
    class Program
    {
        class Product
        {
            public string Name { get; set; }
            public int Price { get; set; }
        }

        /*static int SortWithPrice(Product a, Product b)
        {
            return a.Price.CompareTo(b.Price);
        }*/

        static int SortWithName(Product a, Product b)
        {
            return a.Name.CompareTo(b.Name);
        }

        static void Main(string[] args)
        {
            //정렬관련 내용을 델리게이트로 구현하는 예제
            //델리게이트는 형식화된 메소드이다.
            //특정 형태의 메소드를 매개변수로 전달해 달라는 의미이다.
            //Comparison은 델리게이트이다.
            //마이크로소프트사의 기술문서 참조
            //다음 문서는 Comparison 델리게이트가 지정하고 있는 int 자료형을 반환하고, 매개변수를 두 개 받는 메소드를 매개변수로 지정하고 있다.

            //리스트 생성
            List<Product> products = new List<Product>()
            {
                new Product() {Name = "감  자", Price = 500},
                new Product() {Name = "사  과", Price = 700},
                new Product() {Name = "고구마", Price = 400},
                new Product() {Name = "배  추", Price = 600},
                new Product() {Name = "상  추", Price = 300},
            };

            //정렬합니다
            //(1) Sort() 메소드의 매개변수로 메소드 전달
            //products.Sort(SortWithPrice);
            products.Sort(SortWithName);

            foreach (var item in products)
            {
                Console.WriteLine(item.Name + " : " + item.Price);
            }
        }
    }
}
