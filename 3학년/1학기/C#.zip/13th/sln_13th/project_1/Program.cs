﻿using System;

namespace project_1
{
    delegate int MyDelegate(int a, int b); //대리자 선언

    class Calculator
    {
        public int Plus(int a, int b) //인스턴스 메소드
        {
            return a + b;
        }

        public static int Minus(int a, int b) //클래스 메소드
        {
            return a - b;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Calculator Calc = new Calculator();
            Console.WriteLine(Calc.Plus(7, 8));
            Console.WriteLine(Calculator.Minus(15, 2));

            //MyDelegate Callback = new MyDelegate(Calc.Plus);
            //Console.WriteLine(Callback(7, 8));

            MyDelegate Callback; //대리자 인스턴스 생성
            Callback = new MyDelegate(Calc.Plus); //대리자의 인스턴스를 생성할 때는 대리자가 참조할 메소드를 매개변수로 넘긴다.
            Console.WriteLine(Callback(3, 4));

            Callback = new MyDelegate(Calculator.Minus);
            Console.WriteLine(Callback(7, 5));

        }
    }
}
