﻿using System;
using System.Collections.Generic;

namespace project_5
{
    class Program
    {
        class Product
        {
            public string Name { get; set; }
            public int Price { get; set; }
        }
        static void Main(string[] args)
        {
            //리스트 생성
            List<Product> products = new List<Product>()
            {
                new Product() {Name = "감  자", Price = 500},
                new Product() {Name = "사  과", Price = 700},
                new Product() {Name = "고구마", Price = 400},
                new Product() {Name = "배  추", Price = 600},
                new Product() {Name = "상  추", Price = 300},
            };
            
            //정렬합니다.
            //(3) Sort 메소드의 매개변수로 람다를 지정한다.
            products.Sort( (a,b) => 
            {
                return a.Price.CompareTo(b.Price);
                //return a.Name.CompareTo(b.Name);
            });

            foreach (var item in products)
            {
                Console.WriteLine(item.Name + " : " + item.Price);
            }
        }
    }
}
