﻿using System;

namespace project_4
{
    class MyClass
    {
        //간단한 속성 생성 방법(자동구현 속성)
        private int myField; //변수이름

        public int MyField //속성이름
        {
            get;
            set;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            MyClass obj = new MyClass();
            obj.MyField = 3;
            Console.WriteLine(obj.MyField);
        }
    }
}
