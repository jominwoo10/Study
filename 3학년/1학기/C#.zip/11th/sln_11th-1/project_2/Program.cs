﻿using System;

namespace project_2
{
    class Program
    { 
        //복잡한 방법
        //변수를 바로 변경할 수 없지만 변수를 변경하는 메소드를 만들고 메소드를 호출해 변경
        //getter / setter
        class MyClass
        {
            private int myField;
            public int GetMyField()
            {
                return myField;
            }

            public void  SetMyField(int NewValue)
            {
                myField = NewValue;
            }
        }
        static void Main(string[] args)
        {
            MyClass obj = new MyClass();
            obj.SetMyField(3);
            Console.WriteLine(obj.GetMyField());
        }
    }
}
