﻿using System;

namespace project_1
{

    class MyClass
    {
        public int myField;
    }
    class Program
    {
        static void Main(string[] args)
        {
            MyClass obj = new MyClass();
            obj.myField = 3;
            Console.WriteLine(obj.myField);
        }
    }
}
