﻿using System;

namespace project_3
{
    class MyClass
    {
        //일반적인 속성 방법 : 메소드 보다 속성으로
        //속성은 getter와 setter를 손쉽게 만들 수 있는 방법
        //get 접근자 : 필드로부터 값을 읽어오고 (값 추출)
        //set 접근자 : 필드에 값을 할당(저장)
        private int myField;
        
        public int MyField //속성이름 -> 시험
        {
            get
            {
                return myField;
            }

            set 
            {
                myField = value; //매개변수와 같은 기능을 한다.
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            MyClass obj = new MyClass();
            obj.MyField = 3;
            Console.WriteLine(obj.MyField);
        }
    }
}
