﻿using System;

namespace project_1
{
    class Program
    {
        static void Main(string[] args)
        {
            BoxA boxA = new BoxA(-20, 20);
            Console.WriteLine(boxA.Area());
            boxA.width = 10;
            Console.WriteLine(boxA.Area());
            Console.WriteLine();

            BoxB boxB= new BoxB(-20, 20);
            Console.WriteLine(boxB.Area());
            //boxB.width = 10;  -> private로 인한 변경 불가능
            Console.WriteLine();

            BoxC boxC = new BoxC(-20, 20); // -> 음수로 인한 문구 출력
            boxC.SetWidth(10);
            boxC.SetHeight(10);
            Console.WriteLine(boxC.Area());
            Console.WriteLine();

            BoxD boxD = new BoxD(-20, 20); // -> 음수로 인한 문구 출력
            boxD.Width = 10;
            boxD.Height = 10;
            Console.WriteLine(boxD.Area());
            Console.WriteLine();

            BoxE boxE = new BoxE(-20, 20); // -> 음수로 인한 문구 출력
            boxE.Width = 20;
            boxE.Height = 20;
            Console.Write(boxE.Area());
        }
    }
}
