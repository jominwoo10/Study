﻿using System;
using System.Collections.Generic;
using System.Text;

namespace project_1
{
    class BoxD
    {
        //일반적인 속성 생성 방법
        private int width; //변수 이름
        public int Width //속성 이름
        {
            get
            {
                return width;
            }
            set
            {
                if(value > 0)
                {
                    width = value;
                }
                else
                {
                    Console.WriteLine("너비를 자연수로 입력해 주세요.");
                }
            }
        }
        private int height; //변수 이름
        public int Height //속성 이름
        {
            get
            {
                return height;
            }
            set
            {
                if (value > 0)
                {
                    height = value;
                }
                else
                {
                    Console.WriteLine("높이를 자연수로 입력해 주세요.");
                }
            }
        }
        public int Area() //메소드
        {
            return this.width * this.height;
        }

        public BoxD(int width, int height) //생성자
        {
            Width = width;
            Height = height;
        }
    }
}
