﻿using System;
using System.Collections.Generic;
using System.Text;

namespace project_1
{
    class BoxB
    {
        //캡슐화 : 다른 사람이 변수 width, height를 건드리지 못하게 코드 수정
        //private : 클래스의 내부에서만 접근 가능

        private int width; //인스턴스 변수
        private int height;

        public int Area() //인스턴스 메소드
        {
            return this.width * this.height;
        }

        public BoxB(int width, int height) //생성자
        {
            this.width = width;
            this.height = height;
        }
    }
}
