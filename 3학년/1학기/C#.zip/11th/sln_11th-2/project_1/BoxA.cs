﻿using System;
using System.Collections.Generic;
using System.Text;

namespace project_1
{
    class BoxA
    {
        //너비와 높이를 변수로 갖고, 이를 기반으로 사각형의 넓이를 구하는 클래스
        //public : 클래스 내부/외부 모든 곳에서 접근

        public int width; //인스턴스 변수
        public int height;

        public int Area() //인스턴스 메소드
        {
            return this.width * this.height;
        }

        public BoxA(int width, int height) //생성자
        {
            this.width = width;
            this.height = height;
        }
    }
}
