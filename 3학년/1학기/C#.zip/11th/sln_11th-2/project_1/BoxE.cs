﻿using System;
using System.Collections.Generic;
using System.Text;

namespace project_1
{
    class BoxE
    {
        //일반적인 속성 생성 방법
        private int width; //변수 이름
        public int Width //속성 이름
        {
            get;
            set;
        }
        private int height; //변수 이름
        public int Height //속성 이름
        {
            get;
            set;
        }
        public int Area() //메소드
        {
            return this.Width * this.Height;
        }

        public BoxE(int width, int height) //생성자
        {
            Width = width;
            Height = height;
        }
    }
}
