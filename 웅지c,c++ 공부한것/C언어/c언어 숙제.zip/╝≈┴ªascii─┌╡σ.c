#include <stdio.h>

int main(void)
{
	printf("literal int ũ�� : %d \n",sizeof(7));
	printf("literal double ũ�� : %d \n",sizeof(7.14));
	printf("literal char ũ�� : %d \n",sizeof('c'));
	return 0;
}